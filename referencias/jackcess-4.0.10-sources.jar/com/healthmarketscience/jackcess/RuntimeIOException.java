/*
Copyright (c) 2013 James Ahlborn

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package com.healthmarketscience.jackcess;

import java.io.IOException;

/**
 * RuntimeException wrapper around an IOException
 *
 * @author James Ahlborn
 */
public class RuntimeIOException extends IllegalStateException 
{
  private static final long serialVersionUID = 20130315L;  

  public RuntimeIOException(IOException e) 
  {
    this(((e != null) ? e.getMessage() : null), e);
  }

  public RuntimeIOException(String msg, IOException e) 
  {
    super(msg, e);
  }
}
